require(data.table, quietly = TRUE)
require(openxlsx, quietly = TRUE)
require(rpart, quietly = TRUE)
require(rattle, quietly = TRUE)
data_path='/home/baydogan/Courses/Şişecam/data/housingdata.xlsx'

data=data.table(read.xlsx(data_path,sheet='data'))
head(data,10)

classification_data=copy(data)
classification_data[,is_expensive:=as.numeric(MEDV>quantile(MEDV,0.5))]
classification_data[,MEDV:=NULL]
head(classification_data,10)

fit_rtree=rpart(MEDV~.,data,method='anova')
options(repr.plot.width=12, repr.plot.height=12)
fancyRpartPlot(fit_rtree)

predicted=predict(fit_rtree,data)
plot(data$MEDV,predicted)
abline(a=0,b=1,col=2)

fit_rtree=rpart(MEDV~.,data,method='anova',control=rpart.control(cp=0,maxdepth=4))
fancyRpartPlot(fit_rtree)

summary(fit_rtree)

fit_cl_tree=rpart(is_expensive~.,classification_data,method='class')
fancyRpartPlot(fit_cl_tree)

summary(fit_cl_tree)

barplot(fit_cl_tree$variable.importance,horiz=T)



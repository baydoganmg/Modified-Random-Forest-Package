# pi estimation using Monte Carlo Simulation
nof_samples=10000

set.seed(2)
data_points=runif(nof_samples*2,-1,1)
data_points=matrix(data_points,ncol=2)

# points in the square
plot(data_points)



# find the points in the circle
euclidean_distance=sqrt((data_points[,1])^2 + (data_points[,2])^2)

# number of points in the circle
is_in_circle=euclidean_distance<=1
nof_circle=sum(is_in_circle)

estimated_pi=4*nof_circle/nof_samples
print(estimated_pi)
print(pi)




# points in the circle
plot(data_points,col=as.numeric(is_in_circle)+1)


estimate_pi_3d <- function(N) {
  # Generate three N-element vectors of random numbers between -1 and 1
  x <- runif(N, min=-1, max=1)
  y <- runif(N, min=-1, max=1)
  z <- runif(N, min=-1, max=1)

  # Determine the distance of each point from the origin (0,0,0)
  distances <- sqrt(x^2 + y^2 + z^2)

  # Determine which points are inside the sphere (distance less than or equal to 1)
  inside <- distances <= 1

  # Estimate pi: 6 times the proportion of points that fell inside the sphere
  pi_estimate <- 6 * sum(inside) / N

  return(pi_estimate)
}

# Let's estimate pi using our function and N=10,000
N <- 10000
pi_estimate_3d <- estimate_pi_3d(N)
print(paste("With N =", N, "the estimated value of pi is", pi_estimate_3d))


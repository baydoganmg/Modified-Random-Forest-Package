# if packages do not exist, please install. These are the packages to be used through out the lectures
# install.packages('rtools')     #for installing some specific packages
# install.packages('openxlsx')   #for reading from Excel
# install.packages('ggplot2')    #for pretty visualization
# install.packages('data.table') #for efficient data manipulations
# install.packages('skimr') #for fast summary statistics
# install.packages('GGally')  #for pretty correlation visualization
# install.packages('ggcorrplot') #for pretty correlation visualization
# install.packages('repr')  #for plot resizing in html reports
# install.packages('factoextra')  #for future use in clustering
# install.packages('caret')  #for future use in model evaluation
# install.packages('rpart')  #for future use in tree-based modeling
# install.packages('rattle')  #for future use decision tree visualization
# install.packages('randomForest')  #for future use in random forests
# install.packages('knn')  #for future use in gradient boosting models
# install.packages('lubridate')  #for future use data time manipulation

require(openxlsx, quietly = TRUE) #library(openxlsx) is the same
require(ggplot2, quietly = TRUE)
require(data.table, quietly = TRUE)
require(skimr, quietly = TRUE)
require(GGally, quietly = TRUE)
require(ggcorrplot, quietly = TRUE)
require(repr, quietly = TRUE)

# for plot sizing in html reports
options(repr.plot.width=25, repr.plot.height=20)

# this is my path to housing data, change accordingly
data_path='/home/baydogan/Courses/Şişecam/data/housingdata.xlsx'

# The other option is to choose using file manager
#data_path=file.choose()

housing=read.xlsx(data_path,sheet='data')
str(housing)


# numerical statistics of the data
summary_data=skim(housing)
print(summary_data)

housing=data.table(housing)
str(housing)
options(repr.plot.width=7, repr.plot.height=7)
ggplot(housing, aes(x=MEDV)) + geom_histogram()
ggplot(housing, aes(x=MEDV)) + geom_boxplot()
ggplot(housing, aes(x=MEDV,color=as.factor(CHAS))) + geom_boxplot()

options(repr.plot.width=15, repr.plot.height=12)
correl_info=cor(housing)
ggcorrplot(correl_info, 
           hc.order = TRUE, 
           type = "lower",
           lab = TRUE)


options(repr.plot.width=15, repr.plot.height=15)
ggpairs(housing)

# Focusing on a specific variable pair
options(repr.plot.width=7, repr.plot.height=7)
ggplot(housing, aes(x=RAD,y=TAX)) + geom_point()

l_fit = lm(MEDV~.,data=housing)
print(l_fit)
summary(l_fit)
anova(l_fit)

options(repr.plot.width=7, repr.plot.height=7)
plot(l_fit)

#Building models without the intercept
l_fit_no_intercept = lm(MEDV~-1+.,data=housing)
summary(l_fit_no_intercept)

# adding nonlinear features
nlin_housing=copy(housing)
# note that this is data.table data structure notation from data.table package
nlin_housing[,lstat_sq:=LSTAT^2] 
# nlin_housing$lstat_sq = nlin_housing$LSTAT^2 is the same
l_fit_nonlinear = lm(MEDV~.,data=nlin_housing)
summary(l_fit_nonlinear)

# if we have only LSTAT variable it is basically learning a polynomial model of degree 2
nlin_housing=copy(housing)
nlin_housing[,lstat_sq:=LSTAT^2]
l_fit_nonlinear = lm(MEDV~lstat_sq+LSTAT,data=nlin_housing)
summary(l_fit_nonlinear)

options(repr.plot.width=7, repr.plot.height=7)
#### naive R plots ####
#plot(nlin_housing$LSTAT,predict(l_fit_nonlinear,nlin_housing))
#points(nlin_housing$LSTAT,nlin_housing$MEDV,col='red')
#### ggplot ####
dt_plot_copy = copy(housing) # creating new data frame to keep original
dt_plot_copy[,value:=predict(l_fit_nonlinear,nlin_housing)]
dt_plot_copy[,type:='predicted'] # for plotting purposes
dt_plot_actual = copy(housing) # creating another copy of the data frame
dt_plot_actual[,value:=MEDV]
dt_plot_actual[,type:='actual']
dt_final_plot = rbind(dt_plot_copy,dt_plot_actual) # binding them together
ggplot(dt_final_plot, aes(x=LSTAT,y=value,color=type)) + geom_point()

# piecewise linear modeling as an alternative
nlin_housing=copy(housing)
nlin_housing[,lstat_higherpiece:=ifelse(LSTAT>25,LSTAT,0)]
nlin_housing[,lstat_lowerpiece:=ifelse(LSTAT<=25,LSTAT,0)]
l_fit_nonlinear = lm(MEDV~lstat_higherpiece+lstat_lowerpiece,data=nlin_housing)
summary(l_fit_nonlinear)
             
plot(nlin_housing$LSTAT,predict(l_fit_nonlinear,nlin_housing))           
points(nlin_housing$LSTAT,nlin_housing$MEDV,col='red')

# a logarithmic transformation
nlin_housing=copy(housing)
nlin_housing[,lstat_log:=log(LSTAT)]
l_fit_nonlinear_log = lm(MEDV~.,data=nlin_housing)
summary(l_fit_nonlinear_log)

plot(nlin_housing$LSTAT,predict(l_fit_nonlinear_log,nlin_housing))
points(nlin_housing$LSTAT,nlin_housing$MEDV,col='red')

l_fit_nonlinear_log = lm(MEDV~LSTAT+lstat_log,data=nlin_housing)
summary(l_fit_nonlinear_log)

plot(nlin_housing$LSTAT,predict(l_fit_nonlinear_log,nlin_housing))
points(nlin_housing$LSTAT,nlin_housing$MEDV,col='red')

nlin_housing=copy(housing)
nlin_housing[,lstat_log:=log(LSTAT)]
l_fit_nonlinear = lm(MEDV~.,data=nlin_housing)

summary(l_fit_nonlinear)

options(repr.plot.width=7, repr.plot.height=7)
hist(l_fit_nonlinear$residuals)
plot(l_fit_nonlinear)

nlin_housing=copy(housing[-c(369,372,373)])
nlin_housing[,lstat_log:=log(LSTAT)]
l_fit_nonlinear = lm(MEDV~.,data=nlin_housing)
hist(l_fit_nonlinear$residuals)

nlin_housing[,predicted:=predict(l_fit_nonlinear,nlin_housing)]
nlin_housing[,residual:=MEDV-predicted]
head(nlin_housing)

options(repr.plot.width=15, repr.plot.height=15)
ggpairs(nlin_housing)
